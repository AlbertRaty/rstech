RSTECH SYSTEM PULSE BRIDGE 2.0.0

PURPOSE
Provides System Pulse and System Pulse Pro with local Windows performance data:
CPU, physical RAM, GPU, dedicated VRAM, disk activity, system-drive use,
network throughput, process count and system uptime.

INSTALL
1. Extract all files from this ZIP archive.
2. Double-click "Install System Pulse Bridge.cmd".
3. Install System Pulse Pro in CORSAIR iCUE.
4. Allow the widget to access localhost:59696 when iCUE asks.

The bridge starts automatically when you sign in to Windows. It runs without a
window and listens only on this computer at http://localhost:59696.

UNINSTALL
Double-click "Uninstall System Pulse Bridge.cmd" from the extracted folder.

REQUIREMENTS
Windows 10 or Windows 11, CORSAIR iCUE 5.52 or later, and a compatible CORSAIR
keyboard LCD device. Some GPU performance values depend on the installed Windows
display driver. Unsupported metrics are reported as unavailable.

SECURITY AND PRIVACY
No administrator rights, hardware drivers, cloud service, account, analytics or
telemetry are used. See PRIVACY.txt for details.

Publisher: RSTECH
