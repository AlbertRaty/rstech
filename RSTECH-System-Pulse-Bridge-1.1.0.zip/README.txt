RSTECH SYSTEM PULSE BRIDGE 1.1.0

PURPOSE
Provides System Pulse Pro with the real Windows CPU load and physical RAM usage.

INSTALL
1. Extract all files from this ZIP archive.
2. Double-click "Install System Pulse Bridge.cmd".
3. Install System Pulse Pro in CORSAIR iCUE.

The bridge starts automatically when you sign in to Windows. It runs without a
window and listens only on this computer at http://localhost:59696.

UNINSTALL
Double-click "Uninstall System Pulse Bridge.cmd" from the extracted folder.

REQUIREMENTS
Windows 10 or Windows 11, CORSAIR iCUE 5.52 or later, and a compatible CORSAIR
keyboard LCD device.

SECURITY AND PRIVACY
No administrator rights, hardware drivers, cloud service, account, analytics, or
telemetry are used. See PRIVACY.txt for details.

Publisher: RSTECH
