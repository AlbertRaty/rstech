$ErrorActionPreference = "Stop"
$SourceDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$TargetDirectory = Join-Path $env:LOCALAPPDATA "RSTECH\SystemPulseBridge"
$TargetExecutable = Join-Path $TargetDirectory "SystemPulseBridge.exe"

Get-Process -Name "SystemPulseBridge" -ErrorAction SilentlyContinue |
  Where-Object { $_.Path -eq $TargetExecutable } |
  Stop-Process -Force

New-Item -ItemType Directory -Path $TargetDirectory -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $SourceDirectory "SystemPulseBridge.exe") -Destination $TargetExecutable -Force
Copy-Item -LiteralPath (Join-Path $SourceDirectory "README.txt") -Destination $TargetDirectory -Force
Copy-Item -LiteralPath (Join-Path $SourceDirectory "PRIVACY.txt") -Destination $TargetDirectory -Force

$RunKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
New-ItemProperty -Path $RunKey -Name "RSTECH System Pulse Bridge" -Value ('"' + $TargetExecutable + '"') -PropertyType String -Force | Out-Null
Start-Process -FilePath $TargetExecutable -WindowStyle Hidden

Start-Sleep -Milliseconds 900
$Health = Invoke-RestMethod -Uri "http://localhost:59696/health" -TimeoutSec 3
if ($Health.status -ne "ok") { throw "The bridge did not pass its health check." }

Write-Host "RSTECH System Pulse Bridge was installed successfully."
Write-Host "You may close this window."
