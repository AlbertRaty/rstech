$ErrorActionPreference = "Stop"
$TargetDirectory = Join-Path $env:LOCALAPPDATA "RSTECH\SystemPulseBridge"
$TargetExecutable = Join-Path $TargetDirectory "SystemPulseBridge.exe"

Get-Process -Name "SystemPulseBridge" -ErrorAction SilentlyContinue |
  Where-Object { $_.Path -eq $TargetExecutable } |
  Stop-Process -Force

Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run" -Name "RSTECH System Pulse Bridge" -ErrorAction SilentlyContinue

if (Test-Path -LiteralPath $TargetDirectory) {
  Remove-Item -LiteralPath $TargetDirectory -Recurse -Force
}

Write-Host "RSTECH System Pulse Bridge was removed."
Write-Host "You may close this window."
